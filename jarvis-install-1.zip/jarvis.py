import json, os
import requests

MEMORY_FILE = os.path.expanduser("~/.jarvis_memory.json")
CONFIG_FILE = os.path.expanduser("~/jarvis/config.json")

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}

config = load_config()
SUPABASE_URL = config.get("SUPABASE_URL", "")
SUPABASE_KEY = config.get("SUPABASE_KEY", "")
SUPABASE_TABLE = config.get("SUPABASE_TABLE", "jarvis_memory")

def backup_to_supabase(data):
    if not SUPABASE_URL or not SUPABASE_KEY:
        return
    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json"
    }
    url = f"{SUPABASE_URL}/rest/v1/{SUPABASE_TABLE}?id=eq=1"
    requests.patch(url, headers=headers, json=data)
    requests.post(f"{SUPABASE_URL}/rest/v1/{SUPABASE_TABLE}", headers=headers, json=data)

def restore_from_supabase():
    if not SUPABASE_URL or not SUPABASE_KEY:
        return {}
    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}"
    }
    url = f"{SUPABASE_URL}/rest/v1/{SUPABASE_TABLE}?select=*"
    res = requests.get(url, headers=headers)
    if res.ok and res.json():
        return res.json()[0]
    return {}

def load_memory():
    if os.path.exists(MEMORY_FILE):
        with open(MEMORY_FILE) as f:
            return json.load(f)
    return restore_from_supabase()

def save_memory(data):
    with open(MEMORY_FILE, "w") as f:
        json.dump(data, f)
    backup_to_supabase(data)

def main():
    memory = load_memory()
    if "last_message" in memory:
        print(f"🧠 자비스 기억 : "{memory['last_message']}"")
    else:
        print("🧠 자비스가 처음 깨어났습니다. 반가워요, 모세님!")

    user_input = input("🎤 모세님: ")
    response = f"🤖 자비스: 알겠습니다. '{user_input}' 기억했어요."
    print(response)

    memory["last_message"] = user_input
    save_memory(memory)

if __name__ == "__main__":
    main()
