#!/data/data/com.termux/files/usr/bin/bash

mkdir -p ~/jarvis
cp ./jarvis.py ~/jarvis/jarvis.py
cp ./config.sample.json ~/jarvis/config.json

mkdir -p ~/.termux/bin
echo 'python ~/jarvis/jarvis.py' > ~/.termux/bin/jarvis
chmod +x ~/.termux/bin/jarvis

echo '✅ 설치 완료! 이제 "jarvis" 명령어로 실행할 수 있어요.'
