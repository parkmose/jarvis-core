#!/data/data/com.termux/files/usr/bin/bash
echo "🔧 Installing JARVIS..."
pkg update -y
pkg upgrade -y
pkg install -y git python curl unzip
mkdir -p ~/jarvis
cd ~/jarvis
curl -L -o jarvis_files.zip https://raw.githubusercontent.com/parkmose/jarvis-core/main/jarvis_files.zip
unzip -o jarvis_files.zip
chmod +x jarvis.sh
cp jarvis.sh /data/data/com.termux/files/usr/bin/jarvis
echo "✅ JARVIS installed. Type 'jarvis' to start."
